package com.example.amit.hosteldue;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Modify extends AppCompatActivity {
    TextView textView;
    EditText editText2,editText3,editText4,editText5,editText6;
    String roll,fname,mname,lname,hostel,room;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        textView= (TextView) findViewById(R.id.textView);
        editText2= (EditText) findViewById(R.id.editText2);
        editText3= (EditText) findViewById(R.id.editText3);
        editText4= (EditText) findViewById(R.id.editText4);
        editText5= (EditText) findViewById(R.id.editText5);
        editText6= (EditText) findViewById(R.id.editText6);
        roll = getIntent().getStringExtra("roll");
        fname = getIntent().getStringExtra("fname");
        mname = getIntent().getStringExtra("mname");
        lname = getIntent().getStringExtra("lname");
        hostel = getIntent().getStringExtra("hostel");
        room = getIntent().getStringExtra("room");
        textView.setText("Modify "+roll);
        editText2.setText(fname);
        editText3.setText(mname);
        editText4.setText(lname);
        editText5.setText(hostel);
        editText6.setText(room);
    }
    public void Modify(View view){
        fname=editText2.getText().toString();
        mname=editText3.getText().toString();
        lname=editText4.getText().toString();
        hostel=editText5.getText().toString();
        room=editText6.getText().toString();
        if(fname.equals("")){
            Toast.makeText(Modify.this, "First_Name can't be left blank", Toast.LENGTH_SHORT).show();
        }
        else if(lname.equals("")){
            Toast.makeText(Modify.this,"Last_Name can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else if(hostel.equals("")){
            Toast.makeText(Modify.this,"Hostel_Name can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else if(room.equals("")){
            Toast.makeText(Modify.this,"Room_No. can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else {
            BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            backgroundWorker.execute("mod",roll,fname,mname,lname,hostel,room);
            Intent intent= new Intent(Modify.this,SearchResult.class);
            intent.putExtra("roll",roll);
            startActivity(intent);
            Toast.makeText(Modify.this,"Record updated successfully",Toast.LENGTH_LONG).show();
        }
    }
}