package com.example.amit.hosteldue;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ShowBills extends AppCompatActivity {
    String roll,user;
    TableLayout table;
    TextView textView,textView2,add,mod,del;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        table = (TableLayout) findViewById(R.id.table);
        textView = (TextView) findViewById(R.id.textView);
        textView2= (TextView) findViewById(R.id.textView2);
        add = (TextView) findViewById(R.id.tvadd);
        mod= (TextView) findViewById(R.id.tvmod);
        del= (TextView) findViewById(R.id.tvdel);
        user = getIntent().getStringExtra("user");
        roll = getIntent().getStringExtra("roll");
        if(user.equals("admin")){
            textView2.setText("Bills of " + roll);
            add.setText("Add_Bill");
            mod.setText("Modify_Bill");
            del.setText("Delete_Bill");
        }
        if(user.equals("student")) textView2.setText("YOUR BILLS...");
        new BackgroundWork().execute(roll);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowBills.this, AddBill.class);
                intent.putExtra("roll", roll);
                startActivity(intent);
            }
        });
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowBills.this, ModifyBill.class);
                intent.putExtra("roll", roll);
                startActivity(intent);
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowBills.this, DelBill.class);
                intent.putExtra("roll", roll);
                startActivity(intent);
            }
        });
    }
    public class BackgroundWork extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            roll = params[0];
            String show_url = "http://192.168.56.1/hostel/showbills.php?roll="+roll;
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(show_url, "GET");
            try {
                jsonArray = js.getJSONArray("server_response");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String year = jsonObject.get("year").toString();
                    String month = jsonObject.get("month").toString();
                    String type = jsonObject.get("type").toString();
                    String amount = jsonObject.get("amount").toString();
                    HashMap<String, String> singleEntry = new HashMap<String, String>();
                    singleEntry.put("year", year);
                    singleEntry.put("month", month);
                    singleEntry.put("type", type);
                    singleEntry.put("amount", amount);
                    arrayList.add(singleEntry);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            for(int i=0;i<=arrayList.size();i++){
                TableRow row = new TableRow(ShowBills.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                for (int j = 1; j <= 4; j++) {
                    TextView tv = new TextView(ShowBills.this);
                    tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tv.setPadding(20,20,20,20);
                    if(i==0){
                        if(j==1)
                            tv.setText(Html.fromHtml("<b>Year</b>"));
                        else if(j==2)
                            tv.setText(Html.fromHtml("<b>Month</b>"));
                        else if(j==3)
                            tv.setText(Html.fromHtml("<b>Bill's_Type</b>"));
                        else
                            tv.setText(Html.fromHtml("<b>Amount</b>"));
                    }
                    else {
                        if(j==1)
                            tv.setText(arrayList.get(i - 1).get("year"));
                        else if(j==2)
                            tv.setText(arrayList.get(i - 1).get("month"));
                        else if(j==3)
                            tv.setText(arrayList.get(i - 1).get("type"));
                        else
                            tv.setText(arrayList.get(i - 1).get("amount"));
                    }
                    row.addView(tv);
                }
                table.addView(row);
            }
        }
    }
}