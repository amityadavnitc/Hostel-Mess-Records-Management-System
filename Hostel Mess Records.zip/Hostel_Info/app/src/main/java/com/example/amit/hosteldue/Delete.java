package com.example.amit.hosteldue;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
public class Delete extends AppCompatActivity {
    TextView tvroll;
    String roll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        roll = getIntent().getStringExtra("roll");
        tvroll= (TextView) findViewById(R.id.roll);
        tvroll.setText(roll);
    }
    public void delete(View view){
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute("del",roll);
        Intent intent= new Intent(Delete.this,Search.class);
        startActivity(intent);
        Toast.makeText(Delete.this, "Record deleted successfully", Toast.LENGTH_LONG).show();
    }
}