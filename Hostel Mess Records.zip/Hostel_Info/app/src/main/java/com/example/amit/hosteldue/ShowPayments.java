package com.example.amit.hosteldue;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ShowPayments extends AppCompatActivity {
    String roll,user;
    TableLayout table;
    TextView textView,textView2,add,mod,del;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        table = (TableLayout) findViewById(R.id.table);
        textView = (TextView) findViewById(R.id.textView);
        textView2= (TextView) findViewById(R.id.textView2);
        add = (TextView) findViewById(R.id.tvadd);
        mod= (TextView) findViewById(R.id.tvmod);
        del= (TextView) findViewById(R.id.tvdel);
        roll = getIntent().getStringExtra("roll");
        user = getIntent().getStringExtra("user");
        if(user.equals("admin")) {
            textView2.setText("Payments of " + roll);
            add.setText("Add_Payment");
            mod.setText("Modify_Payment");
            del.setText("Delete_Payment");
        }
        if(user.equals("student")) textView2.setText("YOUR PAYMENTS...");
        new BackgroundWork().execute(roll);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowPayments.this, AddBill.class);
                intent.putExtra("roll", roll);
                startActivity(intent);
            }
        });
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowPayments.this,ModifyBill.class);
                intent.putExtra("roll",roll);
                startActivity(intent);
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowPayments.this, DelBill.class);
                intent.putExtra("roll", roll);
                startActivity(intent);
            }
        });
    }
    public class BackgroundWork extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            roll = params[0];
            String show_url = "http://192.168.56.1/hostel/showpayments.php?roll="+roll;
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(show_url, "GET");
            try {
                jsonArray = js.getJSONArray("server_response");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String date = jsonObject.get("date").toString();
                    String amount = jsonObject.get("amount").toString();
                    HashMap<String, String> singleEntry = new HashMap<String, String>();
                    singleEntry.put("date", date);
                    singleEntry.put("amount", amount);
                    arrayList.add(singleEntry);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            for(int i=0;i<=arrayList.size();i++){
                TableRow row = new TableRow(ShowPayments.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                for (int j = 1; j <= 2; j++) {
                    TextView tv = new TextView(ShowPayments.this);
                    tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tv.setPadding(20,20,20,20);
                    if(i==0){
                        if(j==1)
                            tv.setText(Html.fromHtml("<b>Date</b>"));
                        else
                            tv.setText(Html.fromHtml("<b>Amount</b>"));
                    }
                    else {
                        if(j==1)
                            tv.setText(arrayList.get(i - 1).get("date"));
                        else
                            tv.setText(arrayList.get(i - 1).get("amount"));
                    }
                    row.addView(tv);
                }
                table.addView(row);
            }
        }
    }
}