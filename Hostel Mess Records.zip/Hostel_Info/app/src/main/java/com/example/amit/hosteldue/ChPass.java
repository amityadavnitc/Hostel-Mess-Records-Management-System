package com.example.amit.hosteldue;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class ChPass extends AppCompatActivity {
    EditText editText,editText2,editText3;
    String user,oldpass,newpass,newpass2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ch_pass);
        editText= (EditText) findViewById(R.id.oldpass);
        editText2= (EditText) findViewById(R.id.newpass);
        editText3= (EditText) findViewById(R.id.newpass2);
    }
    public void Change(View view){
        user = getIntent().getStringExtra("user");
        oldpass=editText.getText().toString();
        newpass=editText2.getText().toString();
        newpass2=editText3.getText().toString();
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute("chpass",user,oldpass,newpass,newpass2);
    }
}