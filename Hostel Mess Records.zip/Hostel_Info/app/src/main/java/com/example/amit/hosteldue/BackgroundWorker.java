package com.example.amit.hosteldue;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class BackgroundWorker extends AsyncTask<String,Void,String> {
    Context context;
    AlertDialog alertDialog;
    String type,user,fname,mname,lname,hostel,room,oldpass,newpass,newpass2,year,month,mb,rr,oc,fine,bill,amt;
    BackgroundWorker(Context ctx) {
        context = ctx;
    }
    @Override
    protected String doInBackground(String... params) {
        type=params[0];
        user=params[1];
        try {
            String URL;
            String post_data;
            if(type.equals("due") | type.equals("due2")) URL = "http://192.168.56.1/hostel/showdue.php";
            else if(type.equals("add")){
                fname=params[2];
                mname=params[3];
                lname=params[4];
                hostel=params[5];
                room=params[6];
                URL = "http://192.168.56.1/hostel/add.php";
            }
            else if(type.equals("chpass")){
                oldpass=params[2];
                newpass=params[3];
                newpass2=params[4];
                URL = "http://192.168.56.1/hostel/chpass2.php";
            }
            else if(type.equals("mod")){
                fname=params[2];
                mname=params[3];
                lname=params[4];
                hostel=params[5];
                room=params[6];
                URL = "http://192.168.56.1/hostel/mod2.php";
            }
            else if(type.equals("addBill")){
                year=params[2];
                month=params[3];
                mb=params[4];
                rr=params[5];
                oc=params[6];
                fine=params[7];
                URL = "http://192.168.56.1/hostel/bill.php";
            }
            else if(type.equals("modBill")|type.equals("delBill")){
                year=params[2];
                month=params[3];
                bill=params[4];
                amt=params[5];
                URL = "http://192.168.56.1/hostel/bill.php";
            }
            else URL = "http://192.168.56.1/hostel/del2.php";

            URL url = new URL(URL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

            if(type.equals("due")|type.equals("due2")|type.equals("del")) post_data = URLEncoder.encode("roll", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8");
            else if(type.equals("add") | type.equals("mod")){
                post_data = URLEncoder.encode("roll", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8")
                        +"&"+URLEncoder.encode("fname", "UTF-8") + "=" + URLEncoder.encode(fname, "UTF-8")
                        +"&"+URLEncoder.encode("mname", "UTF-8") + "=" + URLEncoder.encode(mname, "UTF-8")
                        +"&"+URLEncoder.encode("lname", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8")
                        +"&"+URLEncoder.encode("hostel", "UTF-8") + "=" + URLEncoder.encode(hostel, "UTF-8")
                        +"&"+URLEncoder.encode("room", "UTF-8") + "=" + URLEncoder.encode(room, "UTF-8");
            }
            else if(type.equals("addBill")){
                post_data = URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8")
                        +"&"+URLEncoder.encode("roll", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8")
                        +"&"+URLEncoder.encode("year", "UTF-8") + "=" + URLEncoder.encode(year, "UTF-8")
                        +"&"+URLEncoder.encode("month", "UTF-8") + "=" + URLEncoder.encode(month, "UTF-8")
                        +"&"+URLEncoder.encode("mb", "UTF-8") + "=" + URLEncoder.encode(mb, "UTF-8")
                        +"&"+URLEncoder.encode("rr", "UTF-8") + "=" + URLEncoder.encode(rr, "UTF-8")
                        +"&"+URLEncoder.encode("oc", "UTF-8") + "=" + URLEncoder.encode(oc, "UTF-8")
                        +"&"+URLEncoder.encode("fine", "UTF-8") + "=" + URLEncoder.encode(fine, "UTF-8");
            }
            else if(type.equals("modBill")|type.equals("delBill")){
                post_data = URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8")
                        +"&"+URLEncoder.encode("roll", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8")
                        +"&"+URLEncoder.encode("year", "UTF-8") + "=" + URLEncoder.encode(year, "UTF-8")
                        +"&"+URLEncoder.encode("month", "UTF-8") + "=" + URLEncoder.encode(month, "UTF-8")
                        +"&"+URLEncoder.encode("bill", "UTF-8") + "=" + URLEncoder.encode(bill, "UTF-8")
                        +"&"+URLEncoder.encode("amount", "UTF-8") + "=" + URLEncoder.encode(amt, "UTF-8");
            }
            else {
                post_data = URLEncoder.encode("user", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8")
                        +"&"+URLEncoder.encode("op", "UTF-8") + "=" + URLEncoder.encode(oldpass, "UTF-8")
                        +"&"+URLEncoder.encode("np1", "UTF-8") + "=" + URLEncoder.encode(newpass, "UTF-8")
                        +"&"+URLEncoder.encode("np2", "UTF-8") + "=" + URLEncoder.encode(newpass2, "UTF-8");
            }
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(String result) {
        alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setMessage(result);
        if(type.equals("due")) {
            alertDialog.setTitle("Your Due");
            alertDialog.show();
        }
        else if(type.equals("due2")) {
            alertDialog.setTitle(user);
            alertDialog.show();
        }
        else if(type.equals("add")) {
            alertDialog.setTitle("New Student");
            alertDialog.show();
        }
        else if(type.equals("chpass")) {
            alertDialog.setTitle("Change Password");
            alertDialog.show();
        }
        else if(type.equals("addBill")) {
            alertDialog.setTitle("New Bill(s)");
            alertDialog.show();
        }
    }
    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}