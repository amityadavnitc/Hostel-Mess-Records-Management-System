package com.example.amit.hosteldue;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Index extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);
    }
    public void admin(View v){
        Intent intent=new Intent(Index.this,AdminLogin.class);
        startActivity(intent);
    }
    public void student(View v) {
        Intent intent = new Intent(Index.this, MainActivity.class);
        startActivity(intent);
    }
}