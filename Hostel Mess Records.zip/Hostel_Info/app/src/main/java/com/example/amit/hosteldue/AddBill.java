package com.example.amit.hosteldue;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddBill extends AppCompatActivity {
    TextView textView;
    EditText etyear,etmonth,etmb,etrr,etoc,etfine;
    String roll,year,month,mb,rr,oc,fine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bill);
        roll = getIntent().getStringExtra("roll");
        textView= (TextView) findViewById(R.id.tvroll);
        textView.setText(roll);
        etyear= (EditText) findViewById(R.id.editText7);
        etmonth= (EditText) findViewById(R.id.editText8);
        etmb= (EditText) findViewById(R.id.editText9);
        etrr= (EditText) findViewById(R.id.editText10);
        etoc= (EditText) findViewById(R.id.editText11);
        etfine= (EditText) findViewById(R.id.editText12);
    }
    public void insert(View view){
        year=etyear.getText().toString();
        month=etmonth.getText().toString();
        mb=etmb.getText().toString();
        rr=etrr.getText().toString();
        oc=etoc.getText().toString();
        fine=etfine.getText().toString();
        if(year.equals("")) Toast.makeText(AddBill.this, "Year can't be left blank", Toast.LENGTH_SHORT).show();
        else if(month.equals("")) Toast.makeText(AddBill.this, "Month can't be left blank", Toast.LENGTH_SHORT).show();
        else if(mb.equals("")&rr.equals("")&oc.equals("")&fine.equals("")) Toast.makeText(AddBill.this, "All values can't be left blank, Please insert at least one value", Toast.LENGTH_LONG).show();
        else{
            BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            backgroundWorker.execute("addBill",roll,year,month,mb,rr,oc,fine);
        }
    }
}