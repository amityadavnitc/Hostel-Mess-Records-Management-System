package com.example.amit.hosteldue;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Login extends AppCompatActivity {
    String roll,fname,mname,lname,hostel,room;
    TextView tvroll,tvfname,tvmname,tvlname,tvhostel,tvroom;
    JSONArray jsonArray;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        roll = getIntent().getStringExtra("roll");
        tvroll = (TextView) findViewById(R.id.roll);
        tvfname = (TextView) findViewById(R.id.fname);
        tvmname = (TextView) findViewById(R.id.mname);
        tvlname = (TextView) findViewById(R.id.lname);
        tvhostel = (TextView) findViewById(R.id.hostel);
        tvroom = (TextView) findViewById(R.id.room);
        tvroll.setText(roll);
        new BackgroundWork().execute(roll);
    }
    public void due(View view){
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute("due",roll);
    }
    public void bill(View view){
        Intent intent=new Intent(Login.this,ShowBills.class);
        intent.putExtra("user","student");
        intent.putExtra("roll",roll);
        startActivity(intent);
    }
    public void payment(View view){
        Intent intent=new Intent(Login.this,ShowPayments.class);
        intent.putExtra("user","student");
        intent.putExtra("roll",roll);
        startActivity(intent);
    }

    public class BackgroundWork extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String show_url = "http://192.168.56.1/hostel/searchResult.php?roll="+roll;
            JSONParser jsonParser = new JSONParser();
            JSONObject js = jsonParser.makeHttpRequest(show_url, "GET");
            try {
                jsonArray = js.getJSONArray("server_response");
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                fname = jsonObject.get("fname").toString();
                mname = jsonObject.get("mname").toString();
                lname = jsonObject.get("lname").toString();
                hostel = jsonObject.get("hostel").toString();
                room = jsonObject.get("room").toString();
                HashMap<String, String> singleEntry = new HashMap<String, String>();
                singleEntry.put("fname", fname);
                singleEntry.put("mname", mname);
                singleEntry.put("lname", lname);
                singleEntry.put("hostel", hostel);
                singleEntry.put("room", room);
                arrayList.add(singleEntry);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            tvfname.setText(arrayList.get(0).get("fname"));
            tvmname.setText(arrayList.get(0).get("mname"));
            tvlname.setText(arrayList.get(0).get("lname"));
            tvhostel.setText(arrayList.get(0).get("hostel"));
            tvroom.setText(arrayList.get(0).get("room"));
        }
    }
}