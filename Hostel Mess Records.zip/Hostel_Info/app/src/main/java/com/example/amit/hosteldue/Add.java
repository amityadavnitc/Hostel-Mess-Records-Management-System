package com.example.amit.hosteldue;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Add extends AppCompatActivity {
    EditText editText1,editText2,editText3,editText4,editText5,editText6;
    String roll,fname,mname,lname,hostel,room;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        editText1= (EditText) findViewById(R.id.editText1);
        editText2= (EditText) findViewById(R.id.editText2);
        editText3= (EditText) findViewById(R.id.editText3);
        editText4= (EditText) findViewById(R.id.editText4);
        editText5= (EditText) findViewById(R.id.editText5);
        editText6= (EditText) findViewById(R.id.editText6);
    }
    public void Add(View view){
        roll=editText1.getText().toString();
        fname=editText2.getText().toString();
        mname=editText3.getText().toString();
        lname=editText4.getText().toString();
        hostel=editText5.getText().toString();
        room=editText6.getText().toString();
        if(roll.equals("")){
            Toast.makeText(Add.this, "Roll_No. can't be left blank", Toast.LENGTH_SHORT).show();
        }
        else if(fname.equals("")){
            Toast.makeText(Add.this, "First_Name can't be left blank", Toast.LENGTH_SHORT).show();
        }
        else if(lname.equals("")){
            Toast.makeText(Add.this,"Last_Name can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else if(hostel.equals("")){
            Toast.makeText(Add.this,"Hostel_Name can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else if(room.equals("")){
            Toast.makeText(Add.this,"Room_No. can't be left blank",Toast.LENGTH_SHORT).show();
        }
        else {
            BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            backgroundWorker.execute("add",roll,fname,mname,lname,hostel,room);
        }
    }
}